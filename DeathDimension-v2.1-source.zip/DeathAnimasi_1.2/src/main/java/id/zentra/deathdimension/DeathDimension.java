package id.zentra.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class DeathDimension extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private YamlConfiguration lang;
    private RealmManager realm;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadLang();
        realm = new RealmManager(this);
        realm.ensureWorld();
        getServer().getPluginManager().registerEvents(new RealmListener(this, realm), this);
        getServer().getScheduler().runTaskLater(this, () -> {
            for (Player p : getServer().getOnlinePlayers()) realm.recover(p);
        }, 10L);
        getLogger().info("DeathDimension v" + getPluginMeta().getVersion() + " aktif.");
    }

    @Override
    public void onDisable() {
        if (realm != null) realm.shutdown();
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        return new VoidGenerator(); // dipakai Multiverse: -g DeathDimension
    }

    private void loadLang() {
        File f = new File(getDataFolder(), "lang.yml");
        if (!f.exists()) saveResource("lang.yml", false);
        lang = YamlConfiguration.loadConfiguration(f);
    }

    /** Ambil teks lang (MiniMessage) dengan placeholder: msg("key", "time", "5"). */
    public Component msg(String key, String... pairs) {
        String s = lang.getString(key, key);
        for (int i = 0; i + 1 < pairs.length; i += 2) s = s.replace("{" + pairs[i] + "}", pairs[i + 1]);
        return MM.deserialize(s);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(msg("admin-no-perm"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(msg("admin-help"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                reloadConfig();
                loadLang();
                realm.ensureWorld();
                sender.sendMessage(msg("admin-reloaded"));
            }
            case "setspawn" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Hanya untuk pemain.");
                    return true;
                }
                Location l = p.getLocation();
                getConfig().set("dimension-location.world", l.getWorld().getName());
                getConfig().set("dimension-location.x", l.getX());
                getConfig().set("dimension-location.y", l.getY());
                getConfig().set("dimension-location.z", l.getZ());
                getConfig().set("dimension-location.yaw", (double) l.getYaw());
                getConfig().set("dimension-location.pitch", (double) l.getPitch());
                saveConfig();
                sender.sendMessage(msg("admin-spawn-set"));
            }
            case "release", "send" -> {
                Player t = args.length > 1 ? getServer().getPlayerExact(args[1]) : null;
                if (t == null) {
                    sender.sendMessage(msg("admin-player-offline"));
                    return true;
                }
                if (args[0].equalsIgnoreCase("release")) {
                    if (!realm.isInRealm(t) && !realm.isPulling(t)) {
                        sender.sendMessage(msg("admin-not-in-realm", "player", t.getName()));
                        return true;
                    }
                    realm.release(t);
                    sender.sendMessage(msg("admin-released", "player", t.getName()));
                } else {
                    realm.startPull(t);
                    sender.sendMessage(msg("admin-sent", "player", t.getName()));
                }
            }
            default -> sender.sendMessage(msg("admin-help"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("deathdimension.admin")) return out;
        if (args.length == 1) {
            for (String s : List.of("reload", "setspawn", "release", "send"))
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("release") || args[0].equalsIgnoreCase("send"))) {
            for (Player p : getServer().getOnlinePlayers())
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) out.add(p.getName());
        }
        return out;
    }
}
