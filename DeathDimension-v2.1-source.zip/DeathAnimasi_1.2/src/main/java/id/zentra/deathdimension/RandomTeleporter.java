package id.zentra.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.EnumSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

/** Cari lokasi random yang AMAN di overworld (chunk dimuat async, tidak membuat lag). */
final class RandomTeleporter {

    private static final Set<Material> UNSAFE = EnumSet.of(
            Material.LAVA, Material.WATER, Material.FIRE, Material.SOUL_FIRE, Material.CACTUS,
            Material.MAGMA_BLOCK, Material.CAMPFIRE, Material.SOUL_CAMPFIRE, Material.SWEET_BERRY_BUSH,
            Material.POWDER_SNOW, Material.COBWEB, Material.WITHER_ROSE, Material.POINTED_DRIPSTONE,
            Material.BEDROCK);

    private final DeathDimension plugin;
    private final Random rnd = new Random();

    RandomTeleporter(DeathDimension plugin) { this.plugin = plugin; }

    boolean enabled() { return plugin.getConfig().getBoolean("random-teleport.enabled", true); }

    World targetWorld() {
        String n = plugin.getConfig().getString("random-teleport.world", "");
        World w = (n == null || n.isBlank()) ? null : Bukkit.getWorld(n);
        return w != null ? w : Bukkit.getWorlds().get(0);
    }

    CompletableFuture<Location> find() {
        CompletableFuture<Location> f = new CompletableFuture<>();
        World w = targetWorld();
        if (w == null) {
            f.complete(null);
            return f;
        }
        attempt(w, 0, f);
        return f;
    }

    private void attempt(World w, int n, CompletableFuture<Location> f) {
        int max = Math.max(1, plugin.getConfig().getInt("random-teleport.max-attempts", 25));
        if (n >= max) {
            f.complete(fallback(w));
            return;
        }
        int[] xz = pick(w);
        int cx = xz[0] >> 4, cz = xz[1] >> 4;
        w.getChunkAtAsync(cx, cz, true).whenComplete((chunk, ex) -> main(() -> {
            try {
                if (ex != null || chunk == null) {
                    attempt(w, n + 1, f);
                    return;
                }
                Location l = safeAt(w, xz[0], xz[1]);
                if (l == null) {
                    attempt(w, n + 1, f);
                } else {
                    w.addPluginChunkTicket(cx, cz, plugin); // jaga chunk tetap termuat sampai teleport
                    f.complete(l);
                }
            } catch (Exception e) {
                f.complete(fallback(w));
            }
        }));
    }

    void releaseTicket(Location l) {
        if (l == null || l.getWorld() == null) return;
        l.getWorld().removePluginChunkTicket(l.getBlockX() >> 4, l.getBlockZ() >> 4, plugin);
    }

    private int[] pick(World w) {
        var c = plugin.getConfig();
        double min = Math.max(0, c.getDouble("random-teleport.min-radius", 300));
        double max = Math.max(min + 1, c.getDouble("random-teleport.max-radius", 5000));
        double half = w.getWorldBorder().getSize() / 2.0 - 20;
        if (half > 10) max = Math.min(max, half);
        if (min >= max) min = 0;
        double r = Math.sqrt(min * min + rnd.nextDouble() * (max * max - min * min));
        double a = rnd.nextDouble() * Math.PI * 2;
        int x = (int) Math.floor(c.getDouble("random-teleport.center-x", 0) + Math.cos(a) * r);
        int z = (int) Math.floor(c.getDouble("random-teleport.center-z", 0) + Math.sin(a) * r);
        return new int[]{x, z};
    }

    private Location safeAt(World w, int x, int z) {
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y <= w.getMinHeight() + 1 || y + 3 >= w.getMaxHeight()) return null;
        Block ground = w.getBlockAt(x, y, z);
        Material gm = ground.getType();
        if (!gm.isSolid() || UNSAFE.contains(gm) || ground.isLiquid()) return null;
        Block f = w.getBlockAt(x, y + 1, z), h = w.getBlockAt(x, y + 2, z);
        if (!f.isPassable() || !h.isPassable() || f.isLiquid() || h.isLiquid()) return null;
        Location l = new Location(w, x + 0.5, y + 1.0, z + 0.5, rnd.nextFloat() * 360f - 180f, 0f);
        return w.getWorldBorder().isInside(l) ? l : null;
    }

    Location fallback(World w) {
        Location s = w.getSpawnLocation();
        int y = w.getHighestBlockYAt(s.getBlockX(), s.getBlockZ());
        return new Location(w, s.getBlockX() + 0.5, y + 1.0, s.getBlockZ() + 0.5);
    }

    private void main(Runnable r) {
        if (Bukkit.isPrimaryThread()) r.run();
        else Bukkit.getScheduler().runTask(plugin, r);
    }
}
